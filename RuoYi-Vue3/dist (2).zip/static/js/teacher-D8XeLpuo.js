import{P as a}from"./index-CGV8uEDt.js";function r(){return a({url:"/business/teacher/dashboard-data",method:"get"})}export{r as g};
