const t=Object.freeze({choice:"选择题",judgment:"判断题",typing:"打字题",practical:"操作题"});function c(e){return t[e]||"其他题型"}export{c as q};
