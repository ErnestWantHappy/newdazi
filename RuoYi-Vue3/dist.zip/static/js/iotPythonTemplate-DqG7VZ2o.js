import{L as o}from"./index-CkzdAnnx.js";function p(e){return o({url:"/business/iot/experiments",method:"get",params:{lessonId:e}})}function d(e){return o({url:"/business/iot/experiments",method:"post",data:e})}function m(e){return o({url:"/business/iot/lesson-classes",method:"get",params:{lessonId:e}})}function T(e,t,n){return o({url:"/business/iot/class-config",method:"get",params:{experimentId:e,entryYear:t,classCode:n}})}function f(e){return o({url:"/business/iot/generate-grouping",method:"post",data:e})}function g(e){return o({url:"/business/iot/rotate-passcode",method:"post",data:e})}function b(e,t,n){return o({url:"/business/iot/class-card",method:"get",params:{experimentId:e,entryYear:t,classCode:n}})}function I(e){return o({url:`/business/iot/class-config/${e}/sync-broker`,method:"post"})}function y(e,t,n){return o({url:`/business/iot/experiments/${e}/groups`,method:"get",params:{entryYear:t,classCode:n}})}function h(e,t={}){const n=typeof t=="object"?t:{limit:t};return o({url:`/business/iot/experiments/${e}/dashboard`,method:"get",params:n})}function _(e,t={}){return o({url:`/business/iot/experiments/${e}/messages`,method:"get",params:t})}function M(e){return o({url:"/business/iot/student/overview",method:"get",params:{lessonId:e}})}function S(e){return o({url:"/business/iot/student/messages",method:"get",params:e})}async function C(e){if(e==null)return!1;const t=String(e);if(navigator.clipboard&&window.isSecureContext)try{return await navigator.clipboard.writeText(t),!0}catch{}try{return a(t)}catch{return!1}}function a(e){const t=document.createElement("textarea"),n=document.activeElement;t.value=e,t.setAttribute("readonly",""),t.style.contain="strict",t.style.position="absolute",t.style.left="-9999px",t.style.fontSize="12pt";const s=document.getSelection(),r=s&&s.rangeCount>0?s.getRangeAt(0):null;document.body.appendChild(t),t.select(),t.selectionStart=0,t.selectionEnd=e.length;let i=!1;try{i=document.execCommand("copy")}catch{i=!1}return t.remove(),r&&s&&(s.removeAllRanges(),s.addRange(r)),n&&typeof n.focus=="function"&&n.focus(),i}function Q(e={}){const t=n=>u(e[n]??"");return`# -*- coding: utf_8 -*-
# 导入 MYBIT 程序库
from npython import *
# 导入 MQTT 程序库
from umqtt.simple import MQTTClient
import time

# 在下面开始写你自己的代码
# 只在实验板本地填写 WiFi，平台不会保存无线密码
WIFI_NAME = "请填写2.4G_WiFi名称"
WIFI_PASSWORD = "请填写WiFi密码"

# 以下参数由学业测评平台生成，请不要改动
MQTT_SERVER = ${t("brokerUrl")}
MQTT_PORT = ${Number(e.brokerPort||1883)}
MQTT_CLIENT_ID = ${t("clientId")}
MQTT_USERNAME = ${t("username")}
MQTT_PASSWORD = ${t("password")}
MQTT_TOPIC = ${t("topic")}

client = None

def connect_wifi():
    # 屏幕显示格式：oled.print(列, 行, 显示内容, 字号)
    oled.print(1,1,"正在连接WiFi",1)
    print("正在连接 WiFi...")
    ip = wifi.connect(WIFI_NAME, WIFI_PASSWORD)
    oled.print(1,1,"WiFi连接成功",1)
    print("WiFi 已连接:", ip)

def connect_mqtt():
    global client
    oled.print(1,1,"正在连接MQTT",1)
    print("正在连接 MQTT...")
    client = MQTTClient(
        MQTT_CLIENT_ID.encode(),
        MQTT_SERVER,
        port=MQTT_PORT,
        user=MQTT_USERNAME.encode(),
        password=MQTT_PASSWORD.encode(),
        keepalive=60
    )
    client.connect()
    oled.print(1,1,"MQTT连接成功",1)
    print("MQTT 已连接")

def publish_value(value):
    global client
    payload = '{"source":"primary-board","value":' + str(value) + '}'
    try:
        client.publish(MQTT_TOPIC.encode(), payload.encode())
        oled.print(1,1,"数据发送成功",1)
        print("发送成功:", payload)
    except OSError as error:
        oled.print(1,1,"连接断开，重连中",1)
        print("发送失败，正在重连:", error)
        time.sleep(2)
        connect_mqtt()
        client.publish(MQTT_TOPIC.encode(), payload.encode())

connect_wifi()
connect_mqtt()

while True:
    # 把 123 换成传感器读数，例如光照、温度或湿度
    publish_value(123)
    time.sleep(5)
`}function u(e){return JSON.stringify(String(e))}export{m as a,y as b,h as c,_ as d,C as e,b as f,T as g,d as h,Q as i,f as j,M as k,p as l,S as m,g as r,I as s};
