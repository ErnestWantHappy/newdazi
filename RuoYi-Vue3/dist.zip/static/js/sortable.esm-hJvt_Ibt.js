import{bC as e,bD as r}from"./index-CkzdAnnx.js";const a=e(r);export{a as r};
