import{O as a}from"./index-8BR585FO.js";function r(){return a({url:"/business/teacher/dashboard-data",method:"get"})}export{r as g};
