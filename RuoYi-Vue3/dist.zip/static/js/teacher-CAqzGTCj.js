import{O as a}from"./index-yaZZ2CQV.js";function r(){return a({url:"/business/teacher/dashboard-data",method:"get"})}export{r as g};
